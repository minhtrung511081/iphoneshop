from django.apps import AppConfig


class PurchasemanagementConfig(AppConfig):
    name = 'PurchaseManagement'
