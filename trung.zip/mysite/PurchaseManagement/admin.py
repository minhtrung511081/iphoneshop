from django.contrib import admin
from PurchaseManagement.models import *
# Register your models here.
admin.site.register(SourceInput)
admin.site.register(PurchaseInvoice)
admin.site.register(PurchaseInvoiceDetails)