from django.apps import AppConfig


class AccountmanagementConfig(AppConfig):
    name = 'AccountManagement'
