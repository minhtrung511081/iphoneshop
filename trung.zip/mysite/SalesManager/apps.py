from django.apps import AppConfig


class ManagesellConfig(AppConfig):
    name = 'managesell'
