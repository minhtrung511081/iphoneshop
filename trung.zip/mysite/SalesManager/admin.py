from django.contrib import admin
from SalesManager.models import *
# Register your models here.
admin.site.register(SalesCart)
admin.site.register(SalesInvoices)