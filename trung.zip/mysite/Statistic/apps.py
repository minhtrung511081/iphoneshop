from django.apps import AppConfig


class StatisticConfig(AppConfig):
    name = 'Statistic'
